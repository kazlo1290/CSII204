import javakara.JavaKaraProgram;

/*
 * COMMANDS:
 *   kara.move()           kara.turnRight()      kara.turnLeft()
 *   kara.putLeaf()        kara.removeLeaf()
 * SENSORS:
 *   kara.treeFront()      kara.treeLeft()       kara.treeRight()
 *   kara.mushroomFront()  kara.onLeaf()
 */
public class PacMan extends JavaKaraProgram {
  private void Zuun2Udaa(){
 kara.turnLeft();
 kara.turnLeft();
 kara.move();
  }
  public void myProgram() {
      kara.removeLeaf();
      while(!kara.treeFront()){
          kara.move();
          if(!kara.onLeaf()){
              Zuun2Udaa();
              kara.turnRight();
              kara.move();
              if(!kara.onLeaf()){
                  Zuun2Udaa();
                  kara.move();
              }
          }
          kara.removeLeaf();
      }
  }
}

        