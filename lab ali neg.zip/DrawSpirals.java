import javakara.JavaKaraProgram;

/*
 * COMMANDS:
 *   kara.move()           kara.turnRight()      kara.turnLeft()
 *   kara.putLeaf()        kara.removeLeaf()
 * SENSORS:
 *   kara.treeFront()      kara.treeLeft()       kara.treeRight()
 *   kara.mushroomFront()  kara.onLeaf()
 */
public class DrawSpirals extends JavaKaraProgram {
  //
  // you can define your methods here:
  //
  public void myProgram() {
      kara.move();
for(int i=1; i<=19; i++){
    for(int j=0; j<i; j++){
    kara.putLeaf();
    kara.move();}
    kara.turnRight();
}
  }
}

        