package lab6;
import acm.program.*;
public class BasicsDemo extends ConsoleProgram {

	public void run() {
		int n, sum = 0;
		for(int i=1; i<=10; i++){
			sum += i;
		}
		print("1-ees 10 hurtelh tsipruudiin niilber: " + sum);
	}

}
