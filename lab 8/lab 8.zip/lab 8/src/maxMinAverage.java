import acm.program.*;
import acm.util.*;
public class maxMinAverage extends ConsoleProgram {
	public void run(){
		double tooluur = 0, max = 0, min = 0, niilber = 0, too;
		print("Ugugdsun toon daraalliin hamgiin ih, hamgiin baga, dundaj utgiig hevledeg program. Ta ehnii toogoo oruulna uu. ");
		while(true){
			if(tooluur == 0){
				too = readInt("Ta ehnii toogoo oruulna uu: ");
				if(too == 0){
					while(too == 0){
						too = readInt("0-ees omno ydaj neg too oruulna uu: ");
					}
				}
				niilber += too;
				max = too;
				min = too;
				tooluur++;
			}
			else if(tooluur > 0){
				too = readInt("Ta daraagiin toog oruulna uu. Hervee toon daraalliig duusgah bol 0-iig oruulna uu: ");
				if(too == 0)
					break;
				else {
					niilber += too;
					if(max < too)
						max = too;
					if(min > too && too != 0)
						min = too;
					tooluur++;
				}
			}
		}
		double dundaj = niilber / tooluur;
		println("Hamgiin ih utga ni: " + max);
		println("Hamgiin baga utga ni: " + min);
		print("Dundaj utga ni: " + dundaj);
	}
}
