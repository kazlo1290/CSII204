import acm.program.*;
import acm.util.*;
public class RandomSentence extends ConsoleProgram{
	public void run(){
		RandomGenerator rand = RandomGenerator.getInstance();
		int a = rand.nextInt(1, 5);
		int b = rand.nextInt(1, 5);
		int c = rand.nextInt(1, 5);
		print(getSentence(a, b, c));
	}
	public String getSubject(int s){
		switch(s){
			case 1:
				return "Child";
			case 2:
				return "Father";
			case 3:
				return "Mother";
			case 4:
				return "Grandmother";
			case 5:
				return "Grandfather";
		}
		return "";
	}
	public String getVerb(int i){
		switch(i){
			case 1:
				return "goes";
			case 2:
				return "likes";
			case 3:
				return "does";
			case 4:
				return "loves";
			case 5:
				return "hate";
		}
		return "";
	}
	public String getLocation(int v){
		switch(v){
			case 1:
				return "teatre";
			case 2:
				return "cake";
			case 3:
				return "work";
			case 4:
				return "his/her hobby";
			case 5:
				return "car";
		}
		return "";
	}
	public String getSentence(int i, int j, int k){
		return getSubject(i) + " " + getVerb(j) + " " + getLocation(k);
	}
}
