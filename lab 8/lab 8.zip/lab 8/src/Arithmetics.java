import acm.util.*;
import acm.program.*;
public class Arithmetics extends ConsoleProgram {
	public static final char ADD = '+';
	public static final char SUB = '-';
	public static final char MULT = '*';
	public static final char DIV = '/';
	RandomGenerator rand = RandomGenerator.getInstance();
	public void run() {
		RandomGenerator rand = RandomGenerator.getInstance();
		// n too sanamsargui sana
		int n = rand.nextInt(0, 10);
		// daraah uildliig n udaa davt
		// 2 moo sanamsargui sana
		// operator sanamsargui sana
		// sanamsargui songoson 2 too bolon operatoriig ilerhiilel baidlaar haruulj garaas hariug unsh
		// tus hariu zuv esehiig shalgaj medeel
		for(int i=0; i<n; i++){
			int a = rand.nextInt(1, 99);
			int b = rand.nextInt(1, 99);
			char op = nextOperator();
			int hariu = readInt(a + " " + op + " " + b + " = " + "?");
			if(hariu == calculate(a, b, op)){
				println("Zuv hariullaa.");
			}
			else
				println("Hariu: " + a + op + b + "=" + calculate(a,b,op));
		}
		
	}
	public static char nextOperator() {
		RandomGenerator rand = RandomGenerator.getInstance();
		switch (rand.nextInt(1, 4)) {
		case 1:
			return ADD;
		case 2:
			return SUB;
		case 3:
			return MULT;
		default:
			return DIV;
		}
	}
	private int calculate(int first, int second, char op){
		int result = 0;
		switch (op) {
		case ADD:
			// нэмэх үйлдэл
			result = first + second;
			break;
		case SUB:
			// хасах үйлдэл
			result = first - second;
			break;
		case MULT:
			// үржих үйлдэл
			result = first * second;
			break;
		case DIV:
			// хуваах үйлдэл
			result = first / second;
			break;
		}
		return result;
	}
}
