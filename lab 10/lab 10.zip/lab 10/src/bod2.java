import acm.program.*;
import acm.graphics.*;
public class bod2 extends GraphicsProgram {
	public void run(){
		// Doorh kod ni add comandaar GImage classiin objectiig helveh uildel
		// new GImage("zuragName.jpg", x, y) ene ni GImage classiin baiguulagch function bogood object uusgene
		add(new GImage("D:/zura/javaLog.jpg"));
	}
}
