import acm.graphics.GLine;
import acm.graphics.GOval;
import acm.program.*;
import acm.util.RandomGenerator;
import java.lang.*;
import java.util.Scanner;
public class hangman extends GraphicsProgram {
	void drawHangman(int i){
			if(i == 0){
				GLine hol2 = new GLine(300, 375, 275, 500);
				add(hol2);
//				 println("GAME OVER!");
//				 println("   ____________");
//				 println("   |          _|_");
//				 println("   |         /   \\");
//				 println("   |        |     |");
//				 println("   |         \\_ _/");
//				 println("   |          _|_");
//				 println("   |         / | \\");
//				 println("   |          / \\ ");
//				 println("___|___      /   \\");
			}
			else if(i == 1) {
				GLine hol1 = new GLine(300, 375, 325, 500);
				add(hol1);
//				 println("   ____________");
//				 println("   |          _|_");
//				 println("   |         /   \\");
//				 println("   |        |     |");
//				 println("   |         \\_ _/");
//				 println("   |           |");
//				 println("   |           |");
//				 println("   |          / \\");
//				 println("___|___      /   \\");
			}
			else if(i == 2) {
				GLine gar2 = new GLine(300, 275, 200, 325);
				add(gar2);
//				println("   ____________");
//				println("   |          _|_");
//				println("   |         /   \\");
//				println("   |        |     |");
//				println("   |         \\_ _/");
//				println("   |           |");
//				println("   |           |");
//				println("   |          /");
//				println("___|___      / ");
			}
			else if(i == 3) {
				GLine gar1 = new GLine(300, 275, 400, 325);
				add(gar1);
//				 println("   ____________");
//				 println("   |          _|_");
//				 println("   |         /   \\");
//				 println("   |        |     |");
//				 println("   |         \\_ _/");
//				 println("   |           |");
//				 println("   |           |");
//				 println("   |");
//				 println("___|___");
			}
			else if(i == 4) {
				GLine biy = new GLine(300, 250, 300, 375);
				add(biy);
//				 println("   ____________");
//				 println("   |          _|_");
//				 println("   |         /   \\");
//				 println("   |        |     |");
//				 println("   |         \\_ _/");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("___|___");
			}
			else if(i == 5) {
				GOval tolgoi = new GOval(250, 150, 100, 100);
				add(tolgoi);
//				 println("   ____________");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   | ");
//				 println("___|___");
			}
			else if(i == 6) {
				GLine utas = new GLine(300, 100, 300, 150);
				add(utas);
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("___|___");
			}
			else if(i == 7) {
				GLine shongiinMod2 = new GLine(100, 100, 300, 100);
				add(shongiinMod2);
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("   |");
//				 println("___|___");
			}
			else if(i == 8) {
				GLine shongiinMod = new GLine(100, 100, 100, 500);
				add(shongiinMod);
//				 println();
//				 println();
//				 println();
//				 println();
//				 println();
//				 println("___|___");
			}
		}
	String getHariult(int i){
		switch(i){
			case 1: return "sar";
			case 2: return "o";
			case 3: return "anis";
			case 4: return "huls";
			default: return "moil";	
		}
	}
	String asuultRandom(int i){
		switch(i){
			case 1: return "Tsasan deer mungun ayga ter yu ve?";
			case 2: return "Nomiin gold yu baidag ve?";
			case 3: return "Уулын хажууд Улаан сувд?";
			case 4: return "Дам дам бучийхай Давхар давхар бучийхай Дээрээ нэг цацагтай?";
			default: return "Хар морь Сүүлээ дааж ядна?";
		}
	}
	String initGame(){
		RandomGenerator rgen = RandomGenerator.getInstance();
		int randomNum = rgen.nextInt(1, 5);
		String hariult = getHariult(randomNum);
		String asuult = asuultRandom(randomNum);
		println(asuult);
		return hariult;
	}
	void playGame(){
		String answer = initGame();
		char[] zuraas = new char[answer.length()];
		for(int i=0; i<answer.length(); i++){
			zuraas[i] = '*';
		}
		int ami = 8;
		int amiHasah = 0;
		while(ami >= 1){
			println("------------------------------------------------------------------------");
			drawHangman(ami);
			println("Tanii ami: " + ami);
			print("Taah ug: ");
			for(int i=0; i<answer.length(); i++){
				print(zuraas[i]);
			}
			println("");
			int win = 0;
			String useg = readLine("Ta useg usgeer taana uu: ");
			for(int i=0; i<answer.length(); i++){
				if(answer.charAt(i) == useg.charAt(0)){
						zuraas[i] = useg.charAt(0);
						amiHasah = 0;
						break;
				}
				else {
					amiHasah = 1;
				}
			}
			if(amiHasah == 1){
				ami--;
			}
			for(int i=0; i<answer.length(); i++){
				if(answer.charAt(i) == zuraas[i])
					win = 1;
				else{
					win = 0;
					break;
				}
			}
			if(win == 1){
				println("------------------------------------------------------------------------");
				println("Zuv taasan hariult: " + answer);
				println("Ta hojloo!!!");
				break;
			}
		}
		if(ami == 0){
			println("------------------------------------------------------------------------");
			drawHangman(0);
			println("Ta hojigdloo!!!");
		}
	}
	public void run(){
		playGame();
	}
}
