import acm.program.*;
import acm.util.RandomGenerator;
import acm.graphics.*;
import java.awt.event.*;
import java.awt.*;
public class DragObjects extends GraphicsProgram{
	       private GObject gobj;
	       private GPoint point ;
           public void init(){
	    	    addKeyListeners();
	    	    addMouseListeners();
           }
       	GOval randomCircle(){
    		RandomGenerator rgen = RandomGenerator.getInstance();
    		int x = rgen.nextInt(100, 500);
    		int y = rgen.nextInt(100, 500);
    		int length = rgen.nextInt(100, 300);
    		int height = rgen.nextInt(100, 300);
    		GOval dugui = new GOval(x, y, length, height);
    		dugui.setFilled(true);
    		dugui.setFillColor(Color.RED);
    		return dugui;
    	}
    	GRect randomRect(){
    		RandomGenerator rgen = RandomGenerator.getInstance();
    		int x = rgen.nextInt(100, 500);
    		int y = rgen.nextInt(100, 500);
    		int length = rgen.nextInt(100, 300);
    		int height = rgen.nextInt(100, 300);
    		GRect dorvoljin = new GRect(x, y, length, height);
    		dorvoljin.setFilled(true);
    		dorvoljin.setFillColor(Color.BLUE);
    		return (dorvoljin);
    	}
    	void createPentagon(){
    		RandomGenerator rgen = RandomGenerator.getInstance();
    		int side = rgen.nextInt(100, 200);
    		int x = rgen.nextInt(100, 500);
    		int y = rgen.nextInt(100, 500);
    		GPolygon tav = new GPolygon();
    		tav.addVertex(-side, 0);
    		tav.addPolarEdge(side, 36);
    		tav.addPolarEdge(side, -36);
    		tav.addPolarEdge(side, -108);
    		tav.addPolarEdge(-side, 0);
    		tav.addPolarEdge(side, 108);
    		tav.setFilled(true);
    		tav.setFillColor(Color.YELLOW);
    		add(tav, x, y);
    	}
    	void randomRombo(){
    		GPolygon dorov = new GPolygon();
    		RandomGenerator rgen = RandomGenerator.getInstance();
    		int side = rgen.nextInt(100, 200);
    		int x = rgen.nextInt(100, 500);
    		int y = rgen.nextInt(100, 500);
    		dorov.addVertex(-side, 0);
    		dorov.addPolarEdge(side, 60);
    		dorov.addPolarEdge(side, 0);
    		dorov.addPolarEdge(side, -120);
    		dorov.setFilled(true);
    		dorov.setFillColor(Color.PINK);
    		add(dorov, x, y);
    	}
    	void createSumSymbol(){
    		GPolygon nemeh = new GPolygon();
    		RandomGenerator rgen = RandomGenerator.getInstance();
    		int side = rgen.nextInt(100, 200);
    		int x = rgen.nextInt(100, 500);
    		int y = rgen.nextInt(100, 500);
    		nemeh.addVertex(-side/3, -side/6);
    		nemeh.addPolarEdge(side, 0);
    		nemeh.addPolarEdge(side, 90);
    		nemeh.addPolarEdge(side, 0);
    		nemeh.addPolarEdge(side, -90);
    		nemeh.addPolarEdge(side, 0);
    		nemeh.addPolarEdge(side, -90);
    		nemeh.addPolarEdge(side, -180);
    		nemeh.addPolarEdge(side, -90);
    		nemeh.addPolarEdge(side, -180);
    		nemeh.addPolarEdge(side, 90);
    		nemeh.addPolarEdge(side, -180);
    		nemeh.setFilled(true);
    		nemeh.setFillColor(Color.GREEN);
    		add(nemeh, x, y);
    	}
    	void ProgramRun(){
    		String useg = readLine("Ymar neg useg oruulna uu: ");
    		if(useg.charAt(0) == 'c'){
    			add(randomCircle());
    		}
    		else if(useg.charAt(0) == 'r'){
    			add(randomRect());
    		}
    		else if(useg.charAt(0) == 'n'){
    			createSumSymbol();
    		}
    		else if(useg.charAt(0) == 'p'){
    			createPentagon();
    		}
    		else if(useg.charAt(0) == 'b'){
    			randomRombo();
    		}
    	}
       public void KeyTyped(KeyEvent e){
       		if(e.getKeyChar() == 'c'){
       			println("C tovch darlaa");
    			add(randomCircle());
    		}
    		else if(e.getKeyChar() == 'r'){
    			println("R tovch darlaa");
    			add(randomRect());
    		}
    		else if(e.getKeyChar() == 'n'){
    			println("N tovch darlaa");
    			createSumSymbol();
    		}
    		else if(e.getKeyChar() == 'p'){
    			println("P tovch darlaa");
    			createPentagon();
    		}
    		else if(e.getKeyChar() == 'b'){
    			println("B tovch darlaa");
    			randomRombo();
    		}
       }
       public void mouseClicked(MouseEvent e){
    	   gobj = getElementAt(e.getX(),e.getY());
    	   remove(gobj);
       }
       
       public void mousePressed(MouseEvent e){
    	   point = new GPoint(e.getPoint());
    	   gobj = getElementAt(point);
       }
       public void mouseDragged(MouseEvent e){
    	   if(gobj != null){
    		   gobj.move(e.getX()-point.getX(),e.getY()-point.getY());
    		   point = new GPoint(e.getPoint());
    	   }
       }
//       	public void run(){
//    		ProgramRun();
//    	}
}